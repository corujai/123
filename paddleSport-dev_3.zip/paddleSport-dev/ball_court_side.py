import cv2
import numpy as np
import os
from ball_detection import ball_detect


def get_net_center(net_coords):
    x = (net_coords[0][0] + net_coords[1][0] + net_coords[2][0] + net_coords[3][0]) / 4
    y = (net_coords[0][1] + net_coords[1][1] + net_coords[2][1] + net_coords[3][1]) / 4
    return (x, y)


def get_ball_center(ball_coords):
    x = int((ball_coords["bbox"][0] + ball_coords["bbox"][2]) / 2)
    y = int((ball_coords["bbox"][1] + ball_coords["bbox"][3]) / 2)
    return (x, y)


def get_side(ball_center, net_coords):

    #net_center_up_y = int((net_coords[2][1] + net_coords[3][1]) / 2)

    net_center_up_x, net_center_up_y = get_net_center(net_coords)

    height = ball_center[1] - net_center_up_y #net_coords[0][1]

    if height >= 0:
        side = "Bottom"
    else:
        side = "Top"

    return side


def ball_cross_net(ball_center, net_coords, thr=10):
    net_center_up_x, net_center_up_y = get_net_center(net_coords)

    # Проверяем, совпадают ли координаты y центра мяча и верхней грани сетки
    #if ball_center[1] == net_center_up_y:
    #print(np.abs(ball_center[1] - net_center_up_y))
    if np.abs(ball_center[1] - net_center_up_y) < thr:
        return True
    else:
        return False

def ball_side_predict(ball_coords_BEV, ball_coords, net_coords, M):
    #ball_coords = ball_detect(video_path, yolo_weights, class_id, confidence, verbose)
    side='None'

    for i in ball_coords:
        if len(ball_coords_BEV[str(i)]) > 0:
            for j in ball_coords_BEV[str(i)]:
                #ball_center = get_ball_center(ball_coords_BEV[str(i)][str(j)])
                ball_center = ball_coords_BEV[str(i)][str(j)]['bbox']
                side = get_side(ball_center, net_coords)
                cross = ball_cross_net(ball_center, net_coords)    
                ball_coords[str(i)][str(j)]["side"] = side
                ball_coords[str(i)][str(j)]["cross"] = cross

    return ball_coords


def main():
    video_path = '/home/svs/Workdir/tennis/paddleSport/test_imgs/2.mp4'
    yolo_weights = '/home/svs/Workdir/tennis/runs/detect/train_750_150ep/weights/best.pt'
    class_id = 0
    out_vid_path = 'court_side_out1.mp4'
    verbose = True
    confidence = 0.3
    # net coords
    net_coords1 = [
        (230, 420),
        (210, 370),
        (735, 191),
        (737, 232),
    ]

    net_coords2 = [
        (134, 515),
        (114, 453),
        (730, 255),
        (730, 307),
    ]

    ball_coords = ball_side_predict(video_path, yolo_weights, class_id, confidence, net_coords1, out_vid_path, verbose)
    print('ball_coords = ', ball_coords)
   

if __name__ == "__main__":
    main()