import cv2
import numpy as np
import os
from yolo_module import detect_YOLO_video
from tracknet_module import detect_TrackNet_video
from config import tracknet_file, inpaintnet_file, save_dir


#def ball_detect(video_path, yolo_weights, class_id, confidence, verbose):
    #ball_coords = detect_YOLO_video(video_path, yolo_weights, class_id, confidence, verbose)

    #return ball_coords

def ball_detect(video_path, tracknet_file, inpaintnet_file, class_id, confidence, verbose):
    ball_coords = detect_TrackNet_video(video_path, tracknet_file, inpaintnet_file, class_id, confidence, save_dir, verbose) 
    return ball_coords


if __name__ == "__main__":

    video_path = 'test_imgs/2.mp4'
    yolo_weights = 'yolov8n.pt'
    class_id = 0
    verbose = True
    confidence = 0.3

    ball_coords = detect_YOLO_video(video_path, yolo_weights, class_id, confidence, verbose)
    print('ball_coords = ', ball_coords)