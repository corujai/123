import supervision as sv
from ultralytics import YOLO
import numpy as np 

from tracker.mc_bot_sort import BoTSORT
from tracker.tracking_utils.timer import Timer
import argparse



parser = argparse.ArgumentParser()
parser.add_argument('--weights', nargs='+', type=str, default='yolov7.pt', help='model.pt path(s)')
parser.add_argument('--source', type=str, default='inference/images', help='source')  # file/folder, 0 for webcam
parser.add_argument('--img-size', type=int, default=1920, help='inference size (pixels)')
parser.add_argument('--conf-thres', type=float, default=0.09, help='object confidence threshold')
parser.add_argument('--iou-thres', type=float, default=0.7, help='IOU threshold for NMS')
parser.add_argument('--device', default='', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
parser.add_argument('--view-img', action='store_true', help='display results')
parser.add_argument('--save-txt', action='store_true', help='save results to *.txt')
parser.add_argument('--save-conf', action='store_true', help='save confidences in --save-txt labels')
parser.add_argument('--nosave', action='store_true', help='do not save images/videos')
parser.add_argument('--classes', nargs='+', type=int, help='filter by class: --class 0, or --class 0 2 3')
parser.add_argument('--agnostic-nms', action='store_true', help='class-agnostic NMS')
parser.add_argument('--augment', action='store_true', help='augmented inference')
parser.add_argument('--update', action='store_true', help='update all models')
parser.add_argument('--project', default='runs/detect', help='save results to project/name')
parser.add_argument('--name', default='exp', help='save results to project/name')
parser.add_argument('--exist-ok', action='store_true', help='existing project/name ok, do not increment')
parser.add_argument('--trace', action='store_true', help='trace model')
parser.add_argument('--hide-labels-name', default=False, action='store_true', help='hide labels')

    # tracking args
parser.add_argument("--track_high_thresh", type=float, default=0.3, help="tracking confidence threshold")
parser.add_argument("--track_low_thresh", default=0.05, type=float, help="lowest detection threshold")
parser.add_argument("--new_track_thresh", default=0.4, type=float, help="new track thresh")
parser.add_argument("--track_buffer", type=int, default=30, help="the frames for keep lost tracks")
parser.add_argument("--match_thresh", type=float, default=0.7, help="matching threshold for tracking")
parser.add_argument("--aspect_ratio_thresh", type=float, default=1.6,
                        help="threshold for filtering out boxes of which aspect ratio are above the given value.")
parser.add_argument('--min_box_area', type=float, default=10, help='filter out tiny boxes')
parser.add_argument("--fuse-score", dest="mot20", default=False, action="store_true",
                        help="fuse score and iou for association")

    # CMC
parser.add_argument("--cmc-method", default="sparseOptFlow", type=str, help="cmc method: sparseOptFlow | files (Vidstab GMC) | orb | ecc")

parser.add_argument("--with-reid", dest="with_reid", default=False, action="store_true", help="with ReID module.")
parser.add_argument("--fast-reid-config", dest="fast_reid_config", default=r"fast_reid/configs/MOT17/sbs_S50.yml",
                        type=str, help="reid config file path")
parser.add_argument("--fast-reid-weights", dest="fast_reid_weights", default=r"pretrained/mot17_sbs_S50.pth",
                        type=str, help="reid config file path")
parser.add_argument('--proximity_thresh', type=float, default=0.5,
                        help='threshold for rejecting low overlap reid matches')
parser.add_argument('--appearance_thresh', type=float, default=0.25,
                        help='threshold for rejecting low appearance similarity reid matches')


def wrap_list(detections_list):
    """
    Заворачивает список в объект Detections.

    Args:
        detections_list: Список объектов Detection.

    Returns:
        Detections: Объект класса Detections.
    """

    # Проверяем, что список содержит объекты Detection.
    for detection in detections_list:
        #if not isinstance(detection, tuple):
            #raise TypeError("detections_list должен содержать объекты Detection.")
        if len(detection) != 7:
            raise ValueError("detection должен содержать 7 элементов.")
    detections = []
    # Извлекаем значения из списка.

            
    xyxy = np.array([detection[:4] for detection in detections_list])
    confidence = np.array([detection[4] for detection in detections_list])
    class_id = np.array([detection[5] for detection in detections_list])
    track_id = np.array([detection[6] for detection in detections_list])

    # Создаем объект Detections.
    detections = sv.Detections(xyxy, None, confidence, class_id, track_id)

    # Задаем свойства объекта Detections.
    '''detections.xyxy = xyxy
    detections.confidence = confidence
    detections.class_id = class_id
    detections.id = None
    detections.mask = None  # Поскольку в вашем списке нет масок, оставляем маску None
    detections.tracker_id = track_id  # Поскольку в вашем списке нет трекер_ид, оставляем трекер_ид None

    # Проверяем валидность данных.
    detections._post_init__()'''

    return detections



opt = parser.parse_args()
opt.jde = False
opt.ablation = False


model = YOLO('/home/svs/Workdir/tennis/runs/detect/train2/weights/best.pt')
VIDEO_PATH = '/home/svs/Workdir/tennis/2.avi'
OUT_VIDEO_PATH = 'padel_out.mp4'

trace_annotator = sv.TraceAnnotator()

video_info = sv.VideoInfo.from_video_path(video_path=VIDEO_PATH)
frames_generator = sv.get_video_frames_generator(source_path=VIDEO_PATH)
#tracker = sv.ByteTrack(track_buffer=10)
tracker = BoTSORT(opt, frame_rate=60.0)
tracker_sv = sv.ByteTrack(track_buffer=30, track_thresh=0.1, match_thresh=0.1)

THRESHOLD = 3

with sv.VideoSink(target_path=OUT_VIDEO_PATH, video_info=video_info) as sink:
    prev_obj_center = np.array([0,0])
    for frame in frames_generator:
        result = model(frame)[0]
        detections_sv = sv.Detections.from_ultralytics(result)
        #detections = tracker.update_with_detections(detections)
        
        #print('detections = ', detections)
        detections_test = []
        for i, coord in enumerate(detections_sv.xyxy):
            #print('coord = ', coord)
            detections_test.append([coord[0], coord[1], coord[2], coord[3], detections_sv.confidence[i], detections_sv.class_id[i]])
        #print('detections_test = ', np.array(detections_test))


        detections_tracker = tracker.update(np.array(detections_test), frame)
       # print('detections = ', detections)

        


        det_list = []
        for t in detections_tracker:
            x1 = int(t.tlbr[0])
            y1 = int(t.tlbr[1])
            x2 = int(t.tlbr[2])
            y2 = int(t.tlbr[3])
            conf = t.score
            clas = int(t.cls)
            id_tr = t.track_id
            det_list.append([x1, y1, x2, y2, conf, clas, id_tr])
    
        if len(detections_tracker) == 0:
            detections = tracker_sv.update_with_detections(detections_sv)
        else:
            detections = wrap_list(det_list)

        annotated_frame = trace_annotator.annotate(
            scene=frame.copy(),
            detections=detections)
        
        bounding_box_annotator = sv.BoundingBoxAnnotator(color=sv.Color(r=255, g=0, b=0), thickness=5)
        annotated_frame = bounding_box_annotator.annotate(
            scene=annotated_frame.copy(),
            detections=detections)
        sink.write_frame(frame=annotated_frame)

 

