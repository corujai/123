import vertexai
from app.models import ChatHistory
from vertexai.preview.generative_models import GenerativeModel, ChatSession, Content, Part
from google.oauth2 import service_account
import json

credentials = service_account.Credentials.from_service_account_file("plenary-edition-anotherone.json")

vertexai.init(project="plenary-edition-396623", location="northamerica-northeast1", credentials=credentials)

def get_chat_response(chat: ChatSession, prompt: str) -> str:
    responses = chat.send_message(prompt, stream=False)
    return responses.text

def chat_message(message, mobile):
	model = GenerativeModel("gemini-1.0-pro-vision-001")
	chat_history = ChatHistory.query.filter(ChatHistory.mobile == mobile).first()
	print("\n\n",chat_history)