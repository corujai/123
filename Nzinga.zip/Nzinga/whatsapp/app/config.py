import os


class Config(object):
    SECRET_KEY = os.environ.get("FLASK_SECRET_KEY") or b'\xf0\xc7\xab,\x84v[n\xe1\x87\xe3\xe8\xc2\x9c\x8f\xc8\x01V\x11%k\x95'
    SQLALCHEMY_DATABASE_URI = "sqlite:///app.sqlite3"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    GOOGLE_OAUTH_CLIENT_ID = os.environ.get("GOOGLE_OAUTH_CLIENT_ID")
    GOOGLE_OAUTH_CLIENT_SECRET = os.environ.get("GOOGLE_OAUTH_CLIENT_SECRET")
    JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY")
    FLASK_ENV = os.environ.get("FLASK_ENV") or "development"
    
    
