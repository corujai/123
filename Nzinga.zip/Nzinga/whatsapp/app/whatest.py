from heyoo import WhatsApp
messenger = WhatsApp("EAAE531lAEvsBO3lcatYkQndQ1iMUF1BoeDe1MyBKw6nMWyyMtXYNl7iPWhF3cZCnuQTQOzsjNZC9wXZBG6VT6kZBcfarN4Iu05rSUZAR4Cy8MzFBChxunazNscbmG59GtOrYzbnGYZCDFCo5iLi52jSIVcW5hSWZBxazhicZBwfdQfZCGdP066Uqj02Uj2HZChpKy5",  phone_number_id='152285394628714')

"""
msg = messenger.send_test_interative(
    recipient_id="244925623934",
    message_data={
        "type": "cta_url",
        "header": {"type": "text", "text": "Available Dates"},
        "body": {"text": "Tap the button below to see available dates."},
        "footer": {"text": "Dates subject to change."},
        "action": {
            "name": "cta_url",
            "parameters": {
                "display_text": "See Dates",
                "url": "https://www.luckyshrub.com?clickID=kqDGWd24Q5TRwoEQTICY7W1JKoXvaZOXWAS7h1P76s0R7Paec4"
            }
        }
    },
)
"""

msg = messenger.send_reply_button(
    recipient_id="244925623934",
    button={
    "type": "product_list",
    "header":{
      "type": "text",
      "text": "HEADER_CONTENT"
    },
    "body": {
      "text": "BODY_CONTENT"
    },
    "footer": {
      "text": "FOOTER_CONTENT"
    },
    "action": {
      "catalog_id": "6804697192900007",
      "sections": [
        {
          "title": "Livros",
          "product_items": [
            { "product_retailer_id": "2" },
          ]

        },
        {
          "title": "Hamburguer",
          "product_items": [
            {"product_retailer_id": "1"},
          ]
        }
      ]
    }
  }
)

"""
msg = messenger.send_test_interative(
    recipient_id="244925623934",
    message_data={
    "type": "product",
    "body": {
      "text": "BODY_TEXT"
    },
    "footer": {
      "text": "FOOTER_TEXT"
    },
    "action": {
      "catalog_id": "6804697192900007",
      "product_retailer_id": "f2"
    }
  }
)
"""


"""
msg = messenger.send_test_interative(
    recipient_id="244925623934",
    message_data={
        "type": "location_request_message",
        "body": {
            "text": "Let us start with your pickup. You can either manually *enter an address* or *share your current location*."
        },
        "action": {
            "name": "send_location"
        }
    },
)
"""

print(msg)

