import requests
from bs4 import BeautifulSoup

list_of_urls = ['https://www.angocarro.com/anuncios/mostrar-99/']
base_url = 'https://www.angocarro.com/anuncios/mostrar-99/pagina-'
num_pages = 20

proxies = {'https': '192.168.42.129:8080'}
headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36'}

urls = [base_url + str(i) + "/" for i in range(2, num_pages + 1)]

list_of_urls.extend(urls)

scraped_data = []


## Scraping Function
def start_scrape():
    ## Loop Through List of URLs
    for url in list_of_urls:

        ## Send Request
        response = requests.get(url, headers=headers, proxies=proxies)

        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')
            cars = soup.select('div.details')
            for car in cars:
                car_title = car.select('h3')[0].get_text()
                print(car_title)
                car_km = car.select('span')[0].get_text()
                print(car_km)
                car_spec = car.select('span')[1].get_text()
                print(car_km)
                car_price = car.select('div.price')[0].get_text()
                print(car_price)
                car_description = car.select('div.description')[0].get_text()
                print(car_price)
                button_phone = car.select("button")[1]
                car_phone = button_phone['data-number']
                print(car_phone)
                button_whatsapp = car.select("button")[2]
                car_whatsapp = button_whatsapp.get('data-number')
                print(car_whatsapp)
                scraped_data.append({
                    'car_title': car_title,
                    'car_km': car_km,
                    'car_spec': car_spec,
                    'car_price': car_price,
                    'car_description': car_description,
                    'car_phone': car_phone,
                    'car_whatsapp': car_whatsapp
                })


                ## Add To Data Output

        pass


if __name__ == "__main__":
    start_scrape()
    print(scraped_data[0])

