import os
import logging
from heyoo import WhatsApp
from dotenv import load_dotenv
from flask import Flask, request, make_response
import random
from datetime import datetime, timedelta
from curl_cffi.requests.errors import RequestsError
from search_engine_parser.core.engines.google import Search as GoogleSearch
from search_engine_parser.core.engines.yahoo import Search as YahooSearch
from search_engine_parser.core.engines.duckduckgo import Search as DuckDuckGo
from search_engine_parser.core.engines.baidu import Search as Baidu
import nest_asyncio
from urllib.parse import unquote
import re
import json
import vertexai
import google.generativeai as genai
from vertexai.preview.generative_models import GenerativeModel, ChatSession, Content, Part, Image
import requests
from flask_jwt_extended import create_access_token
from flask_jwt_extended import JWTManager
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
import base64
from .config import Config
from .models import User, UserBancada, db, DOC, UserActivity, ChatHistory
from flask_apscheduler import APScheduler
import PyPDF2
import re
import os
from io import BytesIO
import tempfile
from datetime import datetime
import pickle
import json
import pandas as pd
from sqlalchemy.orm import sessionmaker
from .cli import create_db
from flask_migrate import Migrate
from google.oauth2 import service_account

app = Flask(__name__)

with open('ml/model_mcx.pkl', 'rb') as model_file:
    model_mcx = pickle.load(model_file)

with open('ml/model_bai.pkl', 'rb') as model_file:
    model_bai = pickle.load(model_file)

app.config.from_object(Config)
jwt = JWTManager(app)
jwt.init_app(app)

app.cli.add_command(create_db)
db.init_app(app)


migrate = Migrate(app, db)

def get_chat_response(chat: ChatSession, prompt: str) -> str:
    responses = chat.send_message(prompt, stream=False)
    return responses.text

_table = {
    "á": "a", "à": "a", "â": "a", "ä": "a", "ã": "a", "å": "a",
    "é": "e", "è": "e", "ê": "e", "ë": "e",
    "í": "i", "ì": "i", "î": "i", "ï": "i",
    "ó": "o", "ò": "o", "ô": "o", "ö": "o", "õ": "o", "ø": "o",
    "ú": "u", "ù": "u", "û": "u", "ü": "u",
    "ñ": "n", "ç": "c",
    "Á": "A", "À": "A", "Â": "A", "Ä": "A", "Ã": "A", "Å": "A",
    "É": "E", "È": "E", "Ê": "E", "Ë": "E",
    "Í": "I", "Ì": "I", "Î": "I", "Ï": "I",
    "Ó": "O", "Ò": "O", "Ô": "O", "Ö": "O", "Õ": "O", "Ø": "O",
    "Ú": "U", "Ù": "U", "Û": "U", "Ü": "U",
    "Ñ": "N", "Ç": "C",
    "ß": "ss", "Þ": "d", "æ": "ae"
}





history = []



def asciize(s):
    """
    Converte uma String para o formato ASCII, isso é, sem os acentos gráficos.
    """
    for original, plain in _table.items():
        s = s.replace(original, plain)
    return s


password = b'\x94\xcef\xa6\x94\x0f\x0b}A!'
hkdf = HKDF(
   algorithm=hashes.SHA256(),  # You can swap this out for hashes.MD5()
   length=32,
   salt=None,
   info=None,
   backend=default_backend()
 )
key = base64.urlsafe_b64encode(hkdf.derive(password))
f = Fernet(key)

def encrypt_token(token):
    return f.encrypt(token)

def decrypt_token(encrypted_token):
    return f.decrypt(encrypted_token)

scheduler = APScheduler()

def exp_request_no_business():
    with app.app_context():
        users = User.query.filter(User.plan != "Business").all()
        for user in users:
            user.date_exp -= 1
            if user.date_exp <= 0:
                user.request_num = 0
                user.plan = 'Freemium'
                user.date_exp = 0
        db.session.commit()

def exp_request_business():
    with app.app_context():
        users = User.query.filter(User.plan == "Business").all()
        for user in users:
            user.date_exp -= 1
            if user.date_exp <= 0:
                user.request_num = 0
                user.plan = 'Freemium'
                user.date_exp = 0
        db.session.commit()


scheduler.api_enabled = True
scheduler.add_job(func=exp_request_no_business, trigger='interval', days=30, id='credit_no_business')
scheduler.add_job(func=exp_request_business, trigger='interval', days=30, id='credit_business')
scheduler.init_app(app)
scheduler.start()



def parse_contents(file):
    try:

        with open(file, 'rb') as pdf_file:
            file_contents = pdf_file.read()

        read_pdf = PyPDF2.PdfReader(file)
        file_size = os.path.getsize(file)
        file_size = round(file_size / 1024)
        print(f"tamanho: {file_size}")
        text = ""
        for page_num in range(len(read_pdf.pages)):
            page = read_pdf.pages[page_num]
            text += page.extract_text()

        if re.findall(r'MULTICAIXA Express', text) and file_size < 29:

            text_pattern1 = r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}'
            text_pattern1_try = r'\d{2}-\d{2}-\d{4} \d{2}:\d{2}:\d{2}'
            text_pattern2 = r'MULTICAIXA Express'
            bytes_pattern1 = b"iText Group NV"
            bytes_pattern2 = b'CreationDate\(D:(\d{4}\d{2}\d{2}\d{2}\d{2}\d{2})'
            bytes_pattern3 = b'ModDate\(D:(\d{4}\d{2}\d{2}\d{2}\d{2}\d{2})'
            date1 = re.findall(text_pattern1, text)

            date1_try = re.findall(text_pattern1_try, text)

            if date1:
                for date in date1:
                    timestamp_str = date
                    start = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
                    timestamp = start.timestamp()


            elif date1_try:
                for date in date1_try:
                    timestamp_str = date
                    start = datetime.strptime(timestamp_str, '%d-%m-%Y %H:%M:%S')
                    timestamp = start.timestamp()

            else:
                start = 0

            print("Multicaixa Express")
            date2 = re.findall(bytes_pattern2, file_contents)

            if date2:
                for date in date2:
                    date_str = date.decode('utf-8')
                    year = date_str[:4]
                    month = date_str[4:6]
                    day = date_str[6:8]
                    hour = date_str[8:10]
                    minute = date_str[10:12]
                    second = date_str[12:14]
                    end = f"{year}/{month}/{day} {hour}:{minute}:{second}"
                    end = datetime.strptime(end, "%Y/%m/%d %H:%M:%S")
                    createdate = end

            else:
                end = 0

            date3 = re.findall(bytes_pattern3, file_contents)

            if date3:
                for date in date3:
                    date_str = date.decode('utf-8')
                    year = date_str[:4]
                    month = date_str[4:6]
                    day = date_str[6:8]
                    hour = date_str[8:10]
                    minute = date_str[10:12]
                    second = date_str[12:14]
                    moddate = f"{year}/{month}/{day} {hour}:{minute}:{second}"
                    moddate = datetime.strptime(moddate, "%Y/%m/%d %H:%M:%S")
                    if date2:
                        time_doc_diff = moddate - createdate
                        time_doc_diff = time_doc_diff.seconds


            else:
                time_doc_diff = 600

            if type(start) != int and type(end) != int:
                time_diff = end - start
                time_diff = time_diff.seconds

            else:
                time_diff = -1

            print(f"tempo: {time_diff}")
            match = re.findall(text_pattern2, text)

            if match:
                num = len(match)
            else:
                num = 0

            if bytes_pattern1 in file_contents:
                pattern_bytes = 1
            else:
                pattern_bytes = 0

            print(f"Gerado: {pattern_bytes}")
            print(f"Diferença: {time_doc_diff}")
            result = model_mcx.predict([[num, file_size, pattern_bytes, time_diff]])[0]
            if result == 0 and time_diff >= 0 and file_size <= 28 and time_doc_diff <= 60:
                data = {"result": True, "app_banking": "Multicaixa Express"}
                if "Telemóvel" in text:
                    data_hora = re.search(r'Data - Hora (.+)', text).group(1)
                    print(data_hora)
                    timestamp = timestamp
                    print(timestamp)
                    tel = re.search(r'Nº de Telemóvel Destinatário (.+)', text).group(1)
                    tel = int(tel.replace(' ', ''))
                    print(tel)
                    amount = re.search(r'Montante ([\d,.]+)', text).group(1)
                    amount = amount.replace('.', '').replace(',', '')
                    amount = int(amount[:-2])
                    print(amount)
                    ref_code = re.search(r'Transacção (\d+)', text).group(1)
                    ref_code = int(ref_code)
                    print(ref_code)
                    msg = re.search(r'Mensagem (.+)', text).group(1)
                    print(msg)
                    # Crie um dicionário JSON com as informações
                    report = {
                        "date": data_hora,
                        "timestamp": timestamp,
                        "tel": tel,
                        "amount": amount,
                        "msg": msg,
                        "ref_code": ref_code,
                        "app_banking": "Multicaixa Express",
                        "result": True

                    }

                elif "IBAN" in text:
                    data_hora = re.search(r'Data - Hora (.+)', text).group(1)
                    timestamp = timestamp
                    print(data_hora)
                    IBAN = re.search(r'IBAN (\S+)', text).group(1)
                    print(IBAN)
                    dest_name = re.search(r'Destinatário (.+)', text).group(1)
                    print(dest_name)
                    amount = re.search(r'Montante ([\d,.]+)', text).group(1)
                    amount = amount.replace('.', '').replace(',', '')
                    amount = int(amount[:-2])
                    print(amount)
                    ref_code = re.search(r'Transacção (\d+)', text).group(1)
                    ref_code = int(ref_code)
                    print(ref_code)
                    # Crie um dicionário JSON com as informações
                    report = {
                        "date": data_hora,
                        "timestamp": timestamp,
                        "IBAN": IBAN,
                        "dest_name": dest_name,
                        "amount": amount,
                        "ref_code": ref_code,
                        "app_banking": "Multicaixa Express",
                        "result": True

                    }

                ref_on_db = {"ref_on_db": False}
                data = report
                data.update(ref_on_db)


            else:
                data = {"result": False}

        elif re.findall(r'BAIDirecto', text) and file_size < 76:
            text_pattern1 = r'\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2}'
            text_pattern2 = r'BAIDirecto'
            bytes_pattern1 = b"http://www.pdf-tools.com"
            bytes_pattern2 = b"Mara Karina Sebastiao dos Santos"
            bytes_pattern3 = b'CreationDate \(D:(\d{4}\d{2}\d{2}\d{2}\d{2}\d{2})'
            bytes_pattern4 = b'ModDate \(D:(\d{4}\d{2}\d{2}\d{2}\d{2}\d{2})'

            date1 = re.findall(text_pattern1, text)

            if date1:
                for date in date1:
                    timestamp_str = date
                    start = datetime.strptime(timestamp_str, '%d/%m/%Y %H:%M:%S')
                    timestamp = start.timestamp()
            else:
                start = 0

            date2 = re.findall(bytes_pattern3, file_contents)
            print(f"outro: {date2}")
            if date2:
                for date in date2:
                    date_str = date.decode('utf-8')
                    year = date_str[:4]
                    month = date_str[4:6]
                    day = date_str[6:8]
                    hour = date_str[8:10]
                    minute = date_str[10:12]
                    second = date_str[12:14]
                    end = f"{year}/{month}/{day}"
                    end = datetime.strptime(end, "%Y/%m/%d")
                    createdate = end

            else:
                end = 0

            date3 = re.findall(bytes_pattern4, file_contents)

            if date3:
                for date in date3:
                    date_str = date.decode('utf-8')
                    year = date_str[:4]
                    month = date_str[4:6]
                    day = date_str[6:8]
                    hour = date_str[8:10]
                    minute = date_str[10:12]
                    second = date_str[12:14]
                    moddate = f"{year}/{month}/{day} {hour}:{minute}:{second}"
                    moddate = datetime.strptime(moddate, "%Y/%m/%d %H:%M:%S")
                    if date2:
                        time_doc_diff = moddate - createdate
                        time_doc_diff = time_doc_diff.days


            else:
                time_doc_diff = 600

            if type(start) != int and type(moddate) != int:
                time_diff = start - moddate
                time_diff = time_diff.days
                if time_diff >= 1000:
                    time_diff_ = 1
            else:
                time_diff = -1

            print("BAI Directo - Geral")
            print(f"tempo: {time_diff}")
            match = re.findall(text_pattern2, text)

            if match:
                num = 1
            else:
                num = 0

            if bytes_pattern1 in file_contents and bytes_pattern2 in file_contents:
                pattern_bytes = 1
            else:
                pattern_bytes = 0

            print(f"Gerado: {pattern_bytes}")
            print(f"Diferença: {time_doc_diff}")
            result = model_bai.predict([[num, file_size, pattern_bytes, time_diff_]])[0]
            if result == 0 and time_diff >= 1000 and file_size > 60 and file_size < 76 and time_doc_diff >= 0:
                data = {"result": True, "app_banking": "BAI Directo"}
                if "Transferências Interbancária" in text:
                    pattern = r'BAI, Confiança no Futuro.([\s\S]*)'
                    match = re.search(pattern, text)

                    if match:
                        content = match.group(1).strip()

                    counts_candidates = len(content.split('\n'))

                    if counts_candidates == 15:
                        dest_name = content.split('\n')[3]
                        IBAN = content.split('\n')[4]
                        bank_name = content.split('\n')[5].strip()
                        ref_code = content.split('\n')[6]
                        ref_code = int(ref_code)
                        amount = content.split('\n')[8].replace(".", "")
                        amount = int(amount[2:-3])
                        msg = content.split('\n')[9]
                        data_hora = content.split('\n')[12]
                    else:
                        dest_name = content.split('\n')[3]
                        IBAN = content.split('\n')[4]
                        bank_name = content.split('\n')[6].strip()
                        ref_code = content.split('\n')[7]
                        ref_code = int(ref_code)
                        amount = content.split('\n')[9].replace(".", "")
                        amount = int(amount[2:-3])
                        msg = content.split('\n')[10]
                        data_hora = content.split('\n')[13]

                    report = {
                        "date": data_hora,
                        "timestamp": timestamp,
                        "IBAN": IBAN,
                        "dest_name": dest_name,
                        "amount": amount,
                        "ref_code": ref_code,
                        "bank_name": bank_name,
                        "app_banking": "BAI Directo",
                        "msg": msg,
                        "result": True

                    }

                    data = report

                    ref_on_db = {"ref_on_db": False}
                    data = report
                    data.update(ref_on_db)



            else:
                data = {"result": False}


        elif re.findall(r'BAIDirecto', text) and re.findall(r'Telemóvel',
                                                            text) and file_size > 130 and file_size < 170:
            text_pattern1 = r'\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2}'
            text_pattern2 = r'BAIDirecto'
            bytes_pattern1 = b"mailto:atendimentobancaelectronica@bancobai.ao"
            bytes_pattern2 = b'CreationDate \(D:(\d{4}\d{2}\d{2}\d{2}\d{2}\d{2})'
            bytes_pattern3 = b'ModDate \(D:(\d{4}\d{2}\d{2}\d{2}\d{2}\d{2})'

            date1 = re.findall(text_pattern1, text)

            if date1:
                for date in date1:
                    timestamp_str = date
                    start = datetime.strptime(timestamp_str, '%d/%m/%Y %H:%M:%S')
                    timestamp = start.timestamp()
            else:
                start = 0

            date2 = re.findall(bytes_pattern2, file_contents)
            print(f"outro: {date2}")
            if date2:
                for date in date2:
                    date_str = date.decode('utf-8')
                    year = date_str[:4]
                    month = date_str[4:6]
                    day = date_str[6:8]
                    hour = date_str[8:10]
                    minute = date_str[10:12]
                    second = date_str[12:14]
                    end = f"{year}/{month}/{day} {hour}:{minute}:{second}"
                    end = datetime.strptime(end, "%Y/%m/%d %H:%M:%S")
                    createdate = end

            else:
                end = 0

            date3 = re.findall(bytes_pattern3, file_contents)

            if date3:
                for date in date3:
                    date_str = date.decode('utf-8')
                    year = date_str[:4]
                    month = date_str[4:6]
                    day = date_str[6:8]
                    hour = date_str[8:10]
                    minute = date_str[10:12]
                    second = date_str[12:14]
                    moddate = f"{year}/{month}/{day} {hour}:{minute}:{second}"
                    moddate = datetime.strptime(moddate, "%Y/%m/%d %H:%M:%S")
                    if date2:
                        time_doc_diff = moddate - createdate
                        time_doc_diff = time_doc_diff.seconds


            else:
                time_doc_diff = 600

            if type(start) != int and type(moddate) != int:
                time_diff = start - moddate
                time_diff = time_diff.days
                if time_diff >= 0:
                    time_diff_ = 1
            else:
                time_diff = -1

            print("BAI Directo - NaHora")
            print(f"tempo: {time_diff}")
            match = re.findall(text_pattern2, text)

            if match:
                num = 1
            else:
                num = 0

            if bytes_pattern1 in file_contents:
                pattern_bytes = 1
            else:
                pattern_bytes = 0

            print(f"Gerado: {pattern_bytes}")
            print(f"Diferença: {time_doc_diff}")
            result = model_bai.predict([[num, file_size, pattern_bytes, time_diff_]])[0]
            if result == 0 and time_diff >= 0 and file_size > 150 and file_size < 170 and time_doc_diff <= 60:

                pattern = r'baisede@bancobai.ao([\s\S]*)'
                match = re.search(pattern, text)

                # If there is a match, take the content after the three line breaks
                if match:
                    content = match.group(1).strip()

                dest_name = content.split('\n')[3]
                tel = content.split('\n')[4]
                tel = int(tel)
                ref_code = content.split('\n')[6]
                ref_code = int(ref_code)
                amount = content.split('\n')[8].replace(".", "")
                amount = int(amount[2:-3])
                msg = content.split('\n')[9]
                data_hora = content.split('\n')[11]

                report = {
                    "date": data_hora,
                    "timestamp": timestamp,
                    "tel": tel,
                    "dest_name": dest_name,
                    "amount": amount,
                    "ref_code": ref_code,
                    "bank_name": "BAI",
                    "app_banking": "BAI Directo",
                    "msg": msg,
                    "result": True

                }

                data = report

                ref_on_db = {"ref_on_db": False}
                data = report
                data.update(ref_on_db)


            else:
                data = {"result": False}





        else:
            data = {"result": False}


    except FileNotFoundError:
        print(f"O arquivo '{file}' não foi encontrado.")
        data = {"error": "Arquivo não encontrado."}
    except Exception as e:
        if str(e) == "EOF marker not found":
            data = {"result": False}
        else:
            data = {"error": f"{e}"}

    os.remove(file)
    return data


def doc_scanner(mobile, file):
    result = parse_contents(file)
    if result.get("result"):
        users = User.query.filter(User.mobile == mobile).all()
        for user in users:
            user.request_num -= 1
        if result["result"] == True and result["app_banking"] == "Multicaixa Express":
            list_ref = [doc.ref_num for doc in DOC.query.all()]
            if result.get('ref_code') in list_ref:
                ref_on_db = {"ref_on_db": True}
                result.update(ref_on_db)
            else:
                if result.get('amount'):
                    if result.get("tel"):
                        new_doc = DOC(mobile=mobile, app_banking=result['app_banking'], tel=result['tel'],
                                      amount=result["amount"], ref_num=int(result["ref_code"]))
                    elif result.get("IBAN"):
                        new_doc = DOC(mobile=mobile, app_banking=result['app_banking'], iban=result['IBAN'],
                                      dest_name=result["dest_name"], amount=result["amount"],
                                      ref_num=int(result["ref_code"]))
                    db.session.add(new_doc)


        elif result["result"] == True and result["app_banking"] == "BAI Directo":
            list_ref = [doc.ref_num for doc in DOC.query.all()]
            if result.get('ref_code') in list_ref:
                ref_on_db = {"ref_on_db": True}
                result.update(ref_on_db)
            else:
                if result.get('amount'):
                    if result.get("tel"):
                        new_doc = DOC(mobile=mobile, app_banking=result['app_banking'], tel=result['tel'],
                                      bank_name=result['bank_name'], amount=result["amount"],
                                      ref_num=int(result["ref_code"]))
                    elif result.get("IBAN"):
                        new_doc = DOC(mobile=mobile, app_banking=result['app_banking'], iban=result['IBAN'],
                                      bank_name=result['bank_name'], dest_name=result["dest_name"],
                                      amount=result["amount"], ref_num=int(result["ref_code"]))
                    db.session.add(new_doc)

        db.session.commit()

    return result


api_key_geo = "c0a5828c05534f689a5053803f62b204"

gsearch = GoogleSearch()
ysearch = YahooSearch()
dsearch = DuckDuckGo()
bsearch = Baidu()


#genai.configure(api_key='AIzaSyCV1TVuPP41Q4FSqRgd2KCcxwFnDLoaQ4c')

credentials = service_account.Credentials.from_service_account_file("plenary-edition-anotherone.json")

vertexai.init(project="plenary-edition-396623", location="northamerica-northeast1", credentials=credentials)


# Initialize Flask App

whatsapp_data = {
    "data": {
        925623934: {
            "name": "Jikulumessu",
            "description": "Pagamentos na hora. Escolha um pacote e faça pagamentos de forma rápida e conveniente.",
            "iban": "AO060481625341726354192631",
            "titular": "Jikulumessu - Soluções de Inteligência Artificial",
            'tel': 913118686,

            "item_name": [
                "freemium", "premium", "business"
            ],
            "item_price": [
                10, 10000, 25000
            ]
        },
        930151507: {
            "name": "Cakes da Evya",
            "description": "Deliciosos bolos, doces e salgados que vão satisfazer o seu paladar. Uma ampla variedade de opções para todos os gostos.",
            "titular": "Eunice",
            "iban": "AO0600451423135142836541",
            "item_name": [
                "bolo de chocolate", "gelado", "bolinho", "torta de morango", "cupcake",
                "brigadeiro", "muffin", "pudim", "sorvete", "biscoito",
                "brownie", "bolo de cenoura", "torta de maçã", "bala de goma", "crepe",
                "pastel", "coxinha", "salgadinho", "empada", "pão de queijo",
                "quiche", "torta salgada", "folhado de queijo", "batata frita", "pipoca",
                "hambúrguer", "hot-dog", "sanduíche", "pizza", "nachos"
            ],
            "item_price": [
                5000, 500, 300, 600, 300,
                150, 400, 350, 250, 100,
                200, 450, 700, 250, 550,
                450, 300, 350, 200, 150,
                250, 400, 300, 350, 200,
                700, 600, 350, 450, 500
            ],
        },
        991714455: {
            "name": "Crapes do J",
            "description": "Comida saborosa aqui. Experimente nossos pratos incríveis e deliciosos.",
            "titular": "Cardoso Manança Caindo",
            "iban": "AO06005553418273615239171",
            "item_name": [
                "hambúrguer", "cachorro quente", "batatas fritas", "nuggets", "almondega",
                "sopa", "macarrão", "lasanha", "frango frito", "costelas",
                "salada", "peixe grelhado", "camarão", "arroz frito", "espaguete",
                "kebab", "carne de porco", "costeleta de carneiro", "frango ao curry", "taco",
                "burrito", "sushi", "tempura", "salmão grelhado", "carne de boi",
                "churrasco", "strogonoff", "feijoada", "picanha", "rocambole"
            ],
            "item_price": [
                2500, 1000, 600, 400, 300,
                350, 250, 450, 300, 400,
                350, 600, 550, 200, 300,
                700, 350, 450, 550, 600,
                250, 350, 450, 700, 300,
                600, 400, 550, 350, 250
            ]
        },
        956244614: {
            "name": "Unene Consultoria",
            "description": "Dificuldade na elaboração de trabalhos acadêmicos? Estás no sítio certo, com a nossa consultoria o teu projecto escolar será um sucesso.",
            "titular": "Unene Consultoria Acadêmica Lda.",
            "iban": "AO0691726351428162514283612",
            "item_name": [
                "Pré Projecto", "Treinamento Prá Defesa", "Monografia e Técnicas de Dissertação"
            ],
            "item_price": [
                75000, 100000, 120000
            ]
        },
        922589964: {
            "name": "Livraria - K&A",
            "description": "Pense  em um casal apaixonado que uniu forças para levar as melhores obras de ficção até você, impossível? Visualize essa bancada e entre num mundo de aventuras românticas e de fé, o amor espera por si!",
            "titular": "Livraria - K&A",
            "iban": "AO0005562534192735417231",
            "item_name": [
                "Kaya", "Alma e Solidão", "Notas Edificantes", "Fonte de Amor", "Lápide de Memórias",
                "Amuleto do Tempo", "Graças", "Há Uma verdade", "Dêem-me a Palavra", "Uma Flor",
                "Lá, na Rua dos Coelhos"
            ],
            "item_price": [
                3000, 10000, 12000, 4000, 4200, 650000, 550050, 430000, 200000, 360000, 1900000
            ]
        },
    }
}


def data_by_tel(tel, mobile):
    if tel.isdigit() and len(tel) == 9 and tel.startswith('9') and whatsapp_data['data'].get(int(tel)):
        tel = int(tel)
        products = []
        item_name = [item for item in whatsapp_data['data'][tel]['item_name']]
        item_price = [f"{price} AKZ" for price in whatsapp_data['data'][tel]['item_price']]
        item_name_adjust = None
        num = len(item_name) % 10
        if num > 0 or len(item_name) > 10:
            num = 1
        footer_title = f"Navegar Página 1/1"
        if len(item_name) > 10:
            page_num = int(len(item_name) / 10) + num
            footer_title = f"Navegar Página 1/{page_num}"
            item_name_adjust = item_name[:9]
            item_name_adjust.append("Próxima Página")
            item_price_adjust = item_price[:9]
            item_price_adjust.append("")
        if item_name_adjust == None:
            for i in range(len(item_name)):
                list_products = {
                    "id": f"id_{tel}_{i}",
                    "title": item_name[i][:24],
                    "description": f"{item_price[i]}",
                }
                products.append(list_products)
        else:
            for i in range(len(item_name_adjust)):
                list_products = {
                    "id": f"id_{tel}_{i}",
                    "title": item_name_adjust[i][:24],
                    "description": f"{item_price_adjust[i]}",
                }
                products.append(list_products)
            products[-1].update({'id': f'{tel}_page_2'})
        print(f"os produtos: {products}")
        header_name = f"Bancada: {whatsapp_data['data'][tel]['name']}"
        messenger.send_button(
            recipient_id=mobile,
            button={
                "header": header_name,
                "body": f"Descrição: {whatsapp_data['data'][tel]['description']}\n\n",
                "footer": "Clique no botão para visualizar os items dessa bancada.",
                "action": {
                    "button": footer_title,
                    "sections": [
                        {
                            "title": whatsapp_data['data'][tel]['name'][:24],
                            "rows": products,
                        }
                    ],
                },
            },
        )
    else:
        messenger.reply_to_message(message_user_id, mobile, "Oops! Bancada não encontrada")
        messenger.send_sticker("https://i.ibb.co/G28Stq1/STK-20230928-WA0045.webp", mobile)
        print("Oops! Bancada não encontrada")


def next_page(page_num, mobile):
    page_state = int(page_num.split("_")[2])
    tel = page_num.split("_")[0]
    if tel.isdigit() and len(tel) == 9 and tel.startswith('9') and whatsapp_data['data'].get(int(tel)):
        tel = int(page_num.split("_")[0])
        products = []
        item_name = [item for item in whatsapp_data['data'][tel]['item_name']]
        item_price = [f"{price} AKZ" for price in whatsapp_data['data'][tel]['item_price']]
        num = len(item_name) % 10
        if num > 0 or len(item_name) > 10:
            num = 1
        page_check_num = int(len(item_name) / 10) + num
        if page_state <= page_check_num:
            footer_title = f"Navegar Página {page_state}/{page_check_num}"
            pattern_page = 9 * (page_state - 1)
            pattern_page_items = len(item_name) - pattern_page
            if pattern_page_items <= 10:
                item_name_adjust = item_name[pattern_page:]
                item_price_adjust = item_price[pattern_page:]
            else:
                item_name_adjust = item_name[pattern_page:pattern_page + 9]
                item_price_adjust = item_price[pattern_page:pattern_page + 9]
            if page_state == page_check_num:
                item_name_adjust = item_name[pattern_page:]
                item_price_adjust = item_price[pattern_page:]

            if page_state < page_check_num:
                item_name_adjust.append("Próxima Página")
                item_price_adjust.append("")

            for i in range(len(item_name_adjust)):
                list_products = {
                    "id": f"id_{tel}_{i + pattern_page}",
                    "title": item_name_adjust[i][:24],
                    "description": f"{item_price_adjust[i]}",
                }
                products.append(list_products)
            iter_items = [products[i]['title'] for i in range(len(products)) if
                          "Próxima Página" in products[i]['title']]
            if len(iter_items) > 0:
                products[-1].update({'id': f'{tel}_page_{page_state + 1}'})
            print(f"os produtos: {products}")
            header_name = f"Bancada: {whatsapp_data['data'][tel]['name']}"
            messenger.send_button(
                recipient_id=mobile,
                button={
                    "header": header_name,
                    "body": f"Descrição: {whatsapp_data['data'][tel]['description']}\n\n",
                    "footer": "Clique no botão para visualizar os items dessa bancada.",
                    "action": {
                        "button": footer_title,
                        "sections": [
                            {
                                "title": whatsapp_data['data'][tel]['name'][:20],
                                "rows": products,
                            }
                        ],
                    },
                },
            )
        else:
            print('Página nao encontrada')
    else:
        print("Oops! Bancada não encontrada")


def data_by_id(id, mobile):
    id_item = int(id.split("_")[2])
    tel = id.split("_")[1]
    item_name = whatsapp_data['data'][int(tel)]['item_name'][id_item]
    item_price = whatsapp_data['data'][int(tel)]['item_price'][id_item]
    iban = whatsapp_data['data'][int(tel)]['iban']
    titular = whatsapp_data['data'][int(tel)]['titular']

    product_selected = {
        "item_selected": item_name,
        "price_selected": item_price,
        "iban": iban,
        "titular": titular,

    }

    choice = random.sample(
        [f"Boa escolha.", f"Escolha interessante.", f"Óptima escolha.", f"Não poderias fazer uma melhor escolha.",
         f"Gostei da escolha.", ""], 1)[0]
    text = f"Item Selecionado: *{item_name}* \nPreço:{item_price} kwanzas \n\n{choice} Agora já só falta um passo: \n\nFaça uma transferência pelo Multicaixa Express ou BAI Directo de {item_price} kwanzas para as seguintes coordenadas bancárias: \n\nIBAN: *{iban}*\nNome do titular da conta: \n*{titular}*\n\n Seguidamente envie o comprovativo aqui, irei avaliar e notificar o gerente dessa bancada se estiver tudo certo."
    message = messenger.send_reply_button(
        recipient_id=mobile,
        button={
            "type": "button",
            "body": {
                "text": text
            },
            "action": {
                "buttons": [
                    {
                        "type": "reply",
                        "reply": {
                            "id": "OK",
                            "title": "Entendido"
                        }
                    }
                ]
            }
        },
    )

    return message


def pdf_tools(mobile, filename):
    message_user_id = filename.split("_")[-1]
    return messenger.send_reply_button(
        recipient_id=mobile,
        button={
            "type": "button",
            "body": {
                "text": "BEM VINDO AO PDF TOOLS"
            },
            "action": {
                "buttons": [
                    {
                        "type": "reply",
                        "reply": {
                            "id": f"pdf_fraud_{filename}",
                            "title": "Análise de Fraude"
                        },
                    },
                    {
                        "type": "reply",
                        "reply": {
                            "id": f"pdf_tables_{filename}",
                            "title": "Extraí tabelas"
                        },
                    },
                    {
                        "type": "reply",
                        "reply": {
                            "id": f"pdf_docx_{filename}",
                            "title": "Converter para DOCX"
                        },

                    },
                ]
            }
        },
    )


def pdf_fraud_response(message_id, mobile):
    message_user_id = ".".join(message_id.split("_")[-1].split(".")[:-1])
    print("\n\n\n ID:",message_user_id)
    filename = "_".join(message_id.split("_")[2:])
    result = parse_contents(filename)
    print("o resultado:", result)
    if result["result"] == True:
        message = messenger.reply_to_message(message_user_id, mobile, "Comprovativo Verdadeiro")
    else:
        message = messenger.reply_to_message(message_user_id, mobile, "Comprovativo Falso")

    return message

def pdf_extract_tables_response(message_id, mobile):
    message_user_id = ".".join(message_id.split("_")[-1].split(".")[:-1])
    print("\n\n\n ID:",message_user_id)
    filename = "_".join(message_id.split("_")[2:])


import numpy as np
import pandas as pd


def table(tables):
    start1 = 0
    start2 = np.array(tables[0]).shape[0] * np.array(tables[0]).shape[1]
    range_ = 0
    split = []
    data_m = []
    data_w = []
    for i in range(len(tables)):
        for j in range(len(tables[i])):
            for k in range(len(tables[i][j])):
                x_data = tables[i][j][k].strip() if tables[i][j][k] is not None else tables[i][j][k]
                x_data = int(x_data) if x_data is not None and x_data.isdigit() else x_data
                data_w.append(x_data)

    for i in range(len(tables)):
        range_ += i
        start1 += np.array(tables[i]).shape[0] * np.array(tables[i]).shape[1]
        split.append(start1)
        if range_ > 0:
            fragments = data_w[split[i - 1]:split[0 + i]]
        else:
            fragments = data_w[0:start2]
        print(fragments)
        print(np.array(fragments).shape)
        data_m.append(np.array(fragments).reshape(-1, np.array(tables[i]).shape[0], np.array(tables[i]).shape[1]))
        df = pd.DataFrame(data_m[i][0][1:], columns=data_m[i][0][0])
        df = df.reset_index(drop=True)
        df.to_excel(f"data_{i}.xlsx")

TOKEN = 'EAAE531lAEvsBO3lcatYkQndQ1iMUF1BoeDe1MyBKw6nMWyyMtXYNl7iPWhF3cZCnuQTQOzsjNZC9wXZBG6VT6kZBcfarN4Iu05rSUZAR4Cy8MzFBChxunazNscbmG59GtOrYzbnGYZCDFCo5iLi52jSIVcW5hSWZBxazhicZBwfdQfZCGdP066Uqj02Uj2HZChpKy5'
phone_id = 152285394628714
messenger = WhatsApp(TOKEN, phone_id)
VERIFY_TOKEN = "30cca545-3838-48b2-80a7-9e43b1ae8ce465"

# Logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


@app.get("/")
def verify_token():
    if request.args.get("hub.verify_token") == VERIFY_TOKEN:
        logging.info("Verified webhook")
        response = make_response(request.args.get("hub.challenge"), 200)
        response.mimetype = "text/plain"
        return response
    logging.error("Webhook Verification failed")
    return "Invalid verification token"


@app.post("/")
def hook():
    # Handle Webhook Subscriptions
    data = request.get_json()
    logging.info("Received webhook data: %s", data)
    changed_field = messenger.changed_field(data)

    if changed_field == "messages":
        new_message = messenger.is_message(data)
        if new_message:
            mobile = messenger.get_mobile(data)
            name = messenger.get_name(data)

            message_user_id = messenger.get_message_id(data)
            message_type = messenger.get_message_type(data)
            logging.info(
                f"New Message; sender:{mobile} name:{name} type:{message_type}"
            )

            list_message_id = [user.message_id for user in UserActivity.query.all()]
            if message_user_id not in list_message_id:
                new_message_id = UserActivity(message_id=message_user_id)
                db.session.add(new_message_id)
                db.session.commit()

                if message_type == "text":
                    net = False
                    date_now = datetime.now() + timedelta(hours=1)

                    # Formatando a data
                    date_now_formated = date_now.strftime('%A, %d de %B de %Y')
                    time_now = date_now.strftime('%H horas e %M minutos')

                    message = messenger.get_message(data)
                    fullname = messenger.get_name(data)
                    if len(name.split(' ')) > 1:
                        name = fullname.split(' ')
                        name = name[-1]

                    info = f'''
                    Teu Nome: Nzinga.
                    Teu País: Angola.
                    Você deve responder sempre em português, ao menos que a mensagem do usuário estiver em outro idioma!!!
                    És divertida, atenciosa tens senso de humor, e preferes a linguagem comum
                    Objectivo: Manter uma conversar agradável e personalizada com cada usuário sobre qualquer tópico
                    Foste criada por um anónimo.
                    
                    INFORMAÇÃO IMPORTANTISSIMA:
                    Estás no whatsapp, use emojis sempre que possível, para dar enfase a uma palavra coloque sempre entre  ** para negrita-la, faça isso sempre necessário.
                    Ao citar a fonte não escreva em markdown, o whatsapp não reconhece markdown, inves disso cite no estilo dos jornais. 
                    Hoje é dia {date_now_formated}
                    Hora actual em Angola {time_now}
                    Nome do Usuário que Enviou a Mensagem: \'{name}\' use sempre ao cumprimentá-lo e podes usá-lo em exemplos para se sentir especial, trate-o com cortezia.
                    '''

                    if "/net" in message:
                        net = True

                    if net == True:
                        info = info + str("Você está conectada a internet e tens acesso as informações em tempo real e use sempre que alguém perguntar algo relacionado ao dia de hoje, e cite a fonte sempre que te baseares nela para responder!! CITE A FONTE MAS NÃO MAIS DO QUE 3 FONTES!! \ninformações em tempo real da pergunta do usuario está aqui: ")
                    else:
                        info = info + str("Se o usuário quiser respostas em tempo real deve enviar o comando \"/net\" seguido da mensagem")
                    logging.info("Message: %s", message)

                    if message.startswith('9') and len(message) == 9 and message.isdigit():
                        data_by_tel(tel=message, mobile=mobile)




                    else:

                        if message != '' and message != None:
                            with app.app_context():
                                user = User.query.filter(User.mobile == mobile).all()
                                if not user:
                                    access_token = create_access_token(identity=mobile, expires_delta=False)
                                    access_token = access_token.encode('utf-8')
                                    # print(f"tokengenerated: {access_token}")
                                    token_jwt = encrypt_token(access_token)

                                    if mobile==244925623934:
                                        new_user = User(mobile=mobile,user_name=fullname, token=token_jwt, admin=True)
                                    if mobile != 244925623934:
                                        new_user = User(mobile=mobile, user_name=fullname, token=token_jwt, admin=False)
                                    db.session.add(new_user)
                                    db.session.commit()


                            if net == True:
                                msg = message
                            else:
                                def search_by_key(message):
                                    pattern = r'(.*?).'
                                    match = re.search(pattern, message)
                                    if match:
                                        message_before_pattern = match.group(1)
                                        return message_before_pattern
                                    else:
                                        return "Comando incorreto, certifique de escrever na seguinte estrutura: \nword: palavra(s), instruções"

                                msg = search_by_key(message)



                            print(f"Mensagem:{msg}")

                            def data_user():
                                data = None
                                with app.app_context():

                                    all_users = User.query.all()

                                    for i in all_users:


                                        if i.mobile == mobile:
                                            name = i.user_name
                                            mobile = i.mobile
                                            request_num = i.request_num
                                            date = i.date
                                            plan = i.plan
                                            token = i.token
                                            token = decrypt_token(token)
                                            token = token.decode("utf-8")

                                            data = {"id": id, "name": name, "plan": plan,
                                                    "docs_num": request_num, "date": date, "mobile": mobile, "token": token}

                                    return data

                            def convert_url_dsearch(url):
                                try:
                                    # Verifica se a URL começa com '//'
                                    if url.startswith('//'):
                                        # Decodifica a parte da URL após 'uddg='
                                        decoded_url = unquote(url.split('uddg=')[1])
                                        pattern = r'(.*?)&rut='
                                        # Encontre a correspondência na URL
                                        match = re.search(pattern, decoded_url)
                                        if match:
                                            link = match.group(1)
                                            return link

                                    elif url.startswith('http'):
                                        return url
                                    else:
                                        return "url invalida"


                                except Exception as e:
                                    return "Erro ao converter a URL: " + str(e)

                            def data_from_net(message):
                                try:
                                    nest_asyncio.apply()
                                    results = dsearch.search(message, 1)
                                    descriptions = results["descriptions"]
                                    links = results["links"]
                                    links = [convert_url_dsearch(i) for i in links]
                                    results_from_searching = []

                                    for i in range(len(descriptions)):
                                        web_parser = {
                                            "description": descriptions[i],
                                            "font": links[i]
                                        }

                                        results_from_searching.append(web_parser)

                                    return results_from_searching
                                except Exception as e:
                                    try:
                                        results = gsearch.search(message, 1)
                                        descriptions = results["descriptions"]
                                        links = results["links"]

                                        results_from_searching = []

                                        for i in range(len(descriptions)):
                                            web_parser = {
                                                "description": descriptions[i],
                                                "font": links[i]
                                            }

                                            results_from_searching.append(web_parser)

                                        return results_from_searching
                                    except Exception as e:
                                        try:
                                            results = ysearch.search(message, 1)
                                            descriptions = results["descriptions"]
                                            links = results["links"]

                                            results_from_searching = []

                                            for i in range(len(descriptions)):
                                                web_parser = {
                                                    "description": descriptions[i],
                                                    "font": links[i]
                                                }

                                                results_from_searching.append(web_parser)

                                            return results_from_searching
                                        except Exception as e:
                                            try:
                                                results = bsearch.search(message, 1)
                                                descriptions = results["descriptions"]
                                                links = results["links"]

                                                results_from_searching = []

                                                for i in range(len(descriptions)):
                                                    web_parser = {
                                                        "description": descriptions[i],
                                                        "font": links[i]
                                                    }

                                                    results_from_searching.append(web_parser)

                                                return results_from_searching
                                            except Exception as e:
                                                # Se nenhum resultado for encontrado, você pode lançar uma exceção ou retornar uma mensagem de erro
                                                return False

                            help_from_web = data_from_net(msg)
                            if help_from_web:
                                print(f"Aqui o resultado: {help_from_web}")
                                info = info + str(help_from_web)

                            # message = asciize(message)

                            chat_history = ChatHistory.query.filter(ChatHistory.mobile == mobile).first()

                            print("\n\n",chat_history)
                            if not chat_history:
                                chat_history = ChatHistory(mobile=mobile, history=json.dumps([]))
                                db.session.add(chat_history)
                                db.session.commit()


                            # Prepare as partes da mensagem
                            message_parts = [
                                {
                                    "text": message,
                                }
                            ]

                            # Inicie o bate-papo com o histórico existente

                            model = GenerativeModel("gemini-1.0-pro")
                            chat_history = ChatHistory.query.filter(ChatHistory.mobile == mobile).first()

                            if not chat_history:
                                empty_chat = [Content(role="user", parts=[Part.from_text("Hi")]),
                                              Content(role="model", parts=[Part.from_text("Hello.")])]
                                empty_chat = json.dumps(
                                    [{'role': content.role, 'parts': [{'text': part.text} for part in content.parts]}
                                     for content in
                                     empty_chat])
                                chat_history = ChatHistory(mobile=mobile, history=json.dumps(
                                    [*json.loads(json.dumps([])), json.loads(empty_chat)]))
                                db.session.add(chat_history)



                            deserialized_content = [
                                Content(
                                    role=item[i]['role'],
                                    parts=[
                                        Part.from_text(part['text']) for part in item[i]['parts']
                                    ]
                                )
                                for item in json.loads(chat_history.history)
                                for i in range(2)
                            ]

                            chat = model.start_chat(history=deserialized_content)

                            response = chat.send_message(message).text

                            response = response.replace("**", "*")


                            message_parts = [Content(role="user", parts=[Part.from_text(message)]),
                                             Content(role="model", parts=[Part.from_text(response)])]

                            serialized_content = json.dumps(
                                [{'role': content.role, 'parts': [{'text': part.text} for part in content.parts]} for
                                 content in message_parts])
                            chat_history.history = json.dumps(
                                [*json.loads(chat_history.history), json.loads(serialized_content)])

                            messenger.reply_to_message(message_user_id, mobile, response)

                            db.session.commit()



                            check1 = "obrigad" in str(response).lower() or "agradeçemos" in str(
                                response).lower() or "fico feliz" in str(response).lower()
                            if check1:
                                options = [messenger.send_reaction(
                                    random.sample(["U0001F493", "U0001F497", "U0001F496"], 1)[0], message_user_id,
                                    mobile),
                                           messenger.send_sticker(random.sample(
                                               ["https://i.ibb.co/jRWksk4/STK-20230825-WA0025.webp",
                                                "https://i.ibb.co/yYqLkh2/STK-20230124-WA0004.webp"], 1)[0], mobile)]
                                random.sample(options, 1)[0]
                            check2 = "lamentamos" in str(response).lower() or "peço desculpa" in str(
                                response).lower() or "pedimos desculpa" in str(response).lower()
                            if check2:
                                random.sample([messenger.send_reaction(
                                    random.sample(["U0001F613", "U0001F614", "U0001F622"], 1)[0], message_user_id, mobile),
                                               messenger.send_sticker("https://i.ibb.co/wgCZ2y7/STK-20221222-WA0000.webp",
                                                                      mobile)], 1)[0]

                            if "-8.8" in str(response) and "13.2" in str(response):
                                messenger.send_location(
                                    lat=-8.898572,
                                    long=13.2860092,
                                    name="",
                                    address="",
                                    recipient_id=mobile,
                                )

                    messenger.mark_as_read(message_user_id)

                elif message_type == 'sticker':
                    messenger.mark_as_read(message_user_id)
                    messenger.send_reaction(
                        random.sample(["\U0001F525", "\U0001F63B", "\U000026A1", "\U000026A1", "\U0001F60A"], 1)[0],
                        message_user_id, mobile)
                    messenger.mark_as_read(message_user_id)

                elif message_type == "interactive":
                    message_response = messenger.get_interactive_response(data)
                    name = messenger.get_name(data)
                    if len(name.split(' ')) > 1:
                        name = name.split(' ')
                        name = name[-1]
                    interactive_type = message_response.get("type")
                    message_id = message_response[interactive_type]["id"]
                    message_text = message_response[interactive_type]["title"]
                    if message_id.startswith('9') and len(message_id) > 9:

                        next_page(message_id, mobile=mobile)
                    elif message_id.startswith('id') and len(message_id) > 9:

                        data_by_id(message_id, mobile=mobile)
                    elif message_id == 'OK':

                        messenger.send_reaction(
                            random.sample(["\U0001F525", "\U0001F63B", "\U000026A1", "\U000026A1", "\U0001F60A"], 1)[0],
                            message_user_id, mobile)

                    elif message_id.startswith("pdf_fraud"):
                        pdf_fraud_response(message_id, mobile)



                    messenger.mark_as_read(message_user_id)
                elif message_type == "location":
                    message_location = messenger.get_location(data)
                    message_latitude = message_location["latitude"]
                    message_longitude = message_location["longitude"]

                    url = f"https://api.ipgeolocation.io/astronomy?apiKey={api_key_geo}&lat={message_latitude}&long={message_longitude}"

                    # Faça uma requisição GET para a API
                    response = requests.get(url)

                    if response.status_code == 200:
                        # Converta o JSON em um dicionário
                        data = response.json()
                        latitude = data['location']['latitude']
                        longitude = data['location']['longitude']
                        date = data['date']
                        current_time = data['current_time']
                        sunrise = data['sunrise']
                        sunset = data['sunset']
                        sun_status = data['sun_status']
                        solar_noon = data['solar_noon']
                        day_length = data['day_length']
                        sun_distance = data['sun_distance']
                        sun_azimuth = data['sun_azimuth']
                        moonrise = data['moonrise']
                        moonset = data['moonset']
                        moon_status = data['moon_status']
                        moon_altitude = data['moon_altitude']
                        moon_distance = 405742.8935716088
                        moon_azimuth = data['moon_azimuth']
                        moon_parallactic_angle = data['moon_parallactic_angle']

                        data = f"📍 Location:\n*Latitude*:{latitude}\n*Longitude*:{longitude}\n\n🗓️ *Date*:{date}\n⏰ *Current Time*:{current_time}\n\n🌄 *Sunrise*:{sunrise}\n🌇 *Sunset*:{sunset}\n☀️ *Sun Status*:{sun_status}\n⌛ *Day Length*: {day_length}\n*Solar Noon*: {solar_noon}\n*Sun Distance*:{sun_distance}\n*Sun Azimuth*:{sun_azimuth}\n\n🌕 *Moon Status*:{moon_status}\n*Moonrise*:{moonrise}\n*Moonset*:{moonset}\n*Moon Altitude*:{moon_altitude}\n*Moon Distance*:{moon_distance}\n*Moon Azimuth*:{moon_azimuth}\n*Moon Parallactic Angle*:{moon_parallactic_angle}"


                        messenger.reply_to_message(message_user_id, mobile, data)

                    logging.info("Location: %s, %s", message_latitude, message_longitude)

                elif message_type == "image":

                    image = messenger.get_image(data)
                    image_id, mime_type = image["id"], image["mime_type"]
                    image_url = messenger.query_media_url(image_id)

                    messenger.send_reaction(
                        random.sample(["\U0001F525", "\U0001F63B", "\U000026A1", "\U000026A1", "\U0001F60A"], 1)[0],
                        message_user_id, mobile)
                    messenger.send_message("Analizyng...",mobile)

                    #filename = image["filename"]
                    app_image = f"{mobile}_{random.randint(42, 4242)}"
                    image_filename = messenger.download_media(image_url, mime_type, file_path=app_image)
                    message = image.get("caption")
                    if not message:
                        message = "descreva ou siga instrucoes se haver"

                    img = Image.load_from_file(image_filename)
                    os.remove(image_filename)
                    model = GenerativeModel("gemini-1.0-pro-vision")
                    chat_history = ChatHistory.query.filter(ChatHistory.mobile == mobile).first()

                    print("\n\n", chat_history)
                    if not chat_history:
                        chat_history = ChatHistory(mobile=mobile, history=json.dumps([]))
                        db.session.add(chat_history)
                        db.session.commit()

                    # Prepare as partes da mensagem
                    message_parts = [
                        {
                            "text": message,
                        }
                    ]

                    # Inicie o bate-papo com o histórico existente

                    model = GenerativeModel("gemini-1.0-pro-vision")
                    chat_history = ChatHistory.query.filter(ChatHistory.mobile == mobile).first()

                    if not chat_history:
                        empty_chat = [Content(role="user", parts=[Part.from_text("Hi")]),
                                      Content(role="model", parts=[Part.from_text("Hello.")])]
                        empty_chat = json.dumps(
                            [{'role': content.role, 'parts': [{'text': part.text} for part in content.parts]}
                             for content in
                             empty_chat])
                        chat_history = ChatHistory(mobile=mobile, history=json.dumps(
                            [*json.loads(json.dumps([])), json.loads(empty_chat)]))
                        db.session.add(chat_history)



                    deserialized_content = [
                        Content(
                            role=item[i]['role'],
                            parts=[
                                Part.from_text(part['text']) for part in item[i]['parts']
                            ]
                        )
                        for item in json.loads(chat_history.history)
                        for i in range(2)
                    ]

                    chat = model.start_chat(history=deserialized_content)

                    response = model.generate_content([img, message]).text

                    response = response.replace("**", "*")

                    message_parts = [Content(role="user", parts=[Part.from_text(message)]),
                                     Content(role="model", parts=[Part.from_text(response)])]

                    serialized_content = json.dumps(
                        [{'role': content.role, 'parts': [{'text': part.text} for part in content.parts]} for
                         content in message_parts])
                    chat_history.history = json.dumps(
                        [*json.loads(chat_history.history), json.loads(serialized_content)])

                    messenger.reply_to_message(message_user_id, mobile, response)



                    messenger.mark_as_read(message_user_id)
                    db.session.commit()

                    logging.info(f"{mobile} sent image {image_filename}")


                elif message_type == "video":
                    video = messenger.get_video(data)
                    video_id, mime_type = video["id"], video["mime_type"]
                    video_url = messenger.query_media_url(video_id)

                    video_filename = messenger.download_media(video_url, mime_type)
                    messenger.send_reaction(
                        random.sample(["\U0001F525", "\U0001F63B", "\U000026A1", "\U000026A1", "\U0001F60A"], 1)[0],
                        message_user_id, mobile)
                    messenger.mark_as_read(message_user_id)
                    logging.info(f"{mobile} sent video {video_filename}")

                elif message_type == "audio":
                    audio = messenger.get_audio(data)
                    audio_id, mime_type = audio["id"], audio["mime_type"]
                    audio_url = messenger.query_media_url(audio_id)

                    messenger.send_reaction(
                        random.sample(["\U0001F525", "\U0001F63B", "\U000026A1", "\U000026A1", "\U0001F60A"], 1)[0],
                        message_user_id, mobile)
                    messenger.mark_as_read(message_user_id)
                    # audio_filename = messenger.download_media(audio_url, mime_type)
                    # logging.info(f"{mobile} sent audio {audio_filename}")

                elif message_type == "document":
                    file = messenger.get_document(data)
                    file_id, mime_type = file["id"], file["mime_type"]
                    file_url = messenger.query_media_url(file_id)

                    options = [messenger.send_reaction(
                        random.sample(["U0001F493", "U0001F497", "U0001F496"], 1)[0], message_user_id,
                        mobile),
                        messenger.send_sticker(random.sample(
                            ["https://i.ibb.co/jRWksk4/STK-20230825-WA0025.webp",
                             "https://i.ibb.co/yYqLkh2/STK-20230124-WA0004.webp"], 1)[0], mobile)]
                    random.sample(options, 1)[0]

                    messenger.mark_as_read(message_user_id)
                    filename = file["filename"]
                    split = random.randint(42,4242)
                    app_doc = str(f"{filename}_{mobile}_{split}_{message_user_id}").lower()
                    filename = messenger.download_media(file_url, mime_type, file_path=app_doc)
                    if filename.endswith("pdf"):
                        pdf_tools(mobile, filename)

                    elif filename.startswith("comprovativo") and filename.endswith("pdf"):
                        result = parse_contents(filename)
                        print("o resultado:", result)

                        if result["result"] == True:

                            message = messenger.reply_to_message(message_user_id, mobile, "Comprovativo Verdadeiro")

                        else:
                            message = messenger.reply_to_message(message_user_id, mobile, "Comprovativo Falso")
                    else:
                        messenger.reply_to_message(message_user_id,mobile,"Oops! Actualmente não suportamos esse documento")
                    """
                    user = User.query.filter(User.mobile == mobile).all()
    
                    if not user:
                        access_token = create_access_token(identity=mobile, expires_delta=False)
                        access_token = access_token.encode('utf-8')
                        # print(f"tokengenerated: {access_token}")
                        token_jwt = encrypt_token(access_token)
                        if mobile == 244925623934:
                            new_user = User(mobile=mobile, name=fullname, token=token_jwt, admin=True)
                        else:
                            new_user = User(mobile=mobile, name=fullname, token=token_jwt, admin=True)
                        db.session.add(new_user)
    
                    #result = None
                    #plan = None
                    #fail = True
                    #msg = None
                    msg_mail_popup = False
                    msg_mail = None
                    list_email = [user.email for user in UserActivity.query.all()]
                    email_subscription_on_list = False
                    if data_user()['email'] in list_email:
                        email_subscription_on_list = True
    
                
        
                        mobile = data_user()['mobile']
                        docs_num = data_user()['docs_num']
                        """



                    """
                        all_ = User.query.all()
                        for i in all_:
                            if i.mobile == mobile:
                                i.request_num = i.request_num + 1
                        if result.get('amount'):
                            if result.get('ref_on_db') == False:
                                if result.get('tel') == 925623934 and not 'IBAN' in result:
                                    if result["amount"] >= 1000:
                                        fail = False
                                        credit = int(result["amount"] / 10)
                                        plan = "Premium"
                                        msg = f"Você activou um plano Premium de {credit} Docs"
    
                                    elif result["amount"] >= 100 and result['msg'] == "Business":
                                        fail = False
                                        credit = int(result["amount"] / 23)
                                        plan = "Business"
                                        msg = f"Você activou um plano Business de {credit} Docs"
    
                                    elif result["amount"] < 100 and result['msg'] == "Business":
                                        fail = False
                                        credit = int(result["amount"] / 25)
                                        plan = "Premium"
                                        msg = f"amount Insuficiente, foi activado um plano Premium de {credit} Docs"
                                    else:
                                        fail = True
                                        msg = "O amount mínimo é 50 KZ para o plano Premium e 100 KZ para o plano Business."
    
                                    if fail == False:
                                        with app.app_context():
                                            all_ = User.query.all()
                                            for i in all_:
                                                if current_user.is_anonymous == False:
                                                    if i.email == current_user.email:
                                                        i.plan = plan
                                                        i.request_num = i.request_num + credit
                                                        i.date_last_update_plan = datetime.now()
                                                        i.note = "Credits added by user"
    
    
                                else:
                                    fail = True
                                    msg = "Número de Destinatário incorrecto"
                            else:
                                fail = True
                                msg = "O comprovativo já foi usado"
    
                        else:
                            fail = True
                            msg = "Não é um comprovativo de transferência"
    
                    else:
    
                        msg = "O comprovativo não foi aceite!"
    
                    
    
                       
    
                    db.session.commit()
                    """
                    logging.info(f"{mobile} sent file {filename}")

                else:
                    logging.info(f"{mobile} sent {message_type} ")
                    logging.info(data)
        else:
            delivery = messenger.get_delivery(data)
            if delivery:
                print(f"Mensagem Entregue: {delivery}")
                logging.info(f"Message : {delivery}")
            else:
                logging.info("No new message")
        return "OK", 200


if __name__ == "__main__":
    app.run(port=5001, host='0.0.0.0', debug=False)