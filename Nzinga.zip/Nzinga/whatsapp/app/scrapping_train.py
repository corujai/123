import httpx

import asyncio
import httpx

proxies = {'https': 'http://192.168.42.129:8080'}
auth = httpx.BasicAuth(username="kissabi", password="amigo1606")

httpx.AsyncClient()
async def main():
    client = httpx.AsyncClient(
        # to limit asynchronous concurrent connections limits can be applied:
        pool_limits=httpx.PoolLimits(max_connections=10),
        # tip: increase timeouts for concurrent connections:
        timeout=httpx.Timeout(60.0),  # seconds
        # note: asyncClient takes in the same arguments like Client (like headers, cookies etc.)
        proxies=proxies
    )
    # to make concurrent requests asyncio.gather can be used:
    urls = [
        "https://droidvpn.com/",
    ]
    responses = asyncio.gather(*[client.get(url) for url in urls])
    # or asyncio.as_completed:
    for result in asyncio.as_completed([client.get(url) for url in urls]):
        response = await result
        print(response.headers['X-Authentication'])
    await client.aclose()


asyncio.run(main())

