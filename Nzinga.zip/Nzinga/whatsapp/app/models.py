from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, String, Integer
from flask import current_app
from datetime import datetime
from uuid import uuid4

db = SQLAlchemy()



class User(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    mobile = db.Column(db.String(20), unique=True, nullable=False)
    admin = db.Column(db.Boolean, nullable=False, default=False)
    plan = db.Column(db.String(100), nullable=False, default='Freemium')
    request_num = db.Column(db.Integer, nullable=False, default=10)
    user_name = db.Column(db.String(256), nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.now())
    date_exp = db.Column(db.Integer, nullable=False, default=1)
    date_last_update_plan = db.Column(db.DateTime, nullable=False, default=datetime.now())
    token = db.Column(db.String, unique=True, nullable=False)
    public_id = db.Column(db.String(36), unique=True, default=lambda: str(uuid4()))
    note = db.Column(db.String(256))
    

class DOC(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    mobile = db.Column(db.String(256), nullable=False)
    admin = db.Column(db.Boolean, nullable=False, default=False)
    bank_name = db.Column(db.String(256))
    app_banking = db.Column(db.String(100))
    iban = db.Column(db.String(256))
    tel = db.Column(db.Integer)
    dest_name = db.Column(db.String(256))
    amount = db.Column(db.Integer, nullable=False)
    ref_num = db.Column(db.Integer, nullable=False, unique=True)
    date = db.Column(db.DateTime, nullable=False, default=datetime.now())

class UserBancada(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    email = db.Column(db.String(256), unique=True, nullable=False)
    description = db.Column(db.String,nullable=False)
    iban = db.Column(db.String(256),nullable=False)
    tel = db.Column(db.Integer, nullable=False, default=0)
    titular_tel = db.Column(db.String(256), nullable=False, default="Anonimo")
    titular_iban = db.Column(db.String(256), nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.now())


class DataBancada(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    email = db.Column(db.String(256), nullable=False)
    item_name = db.Column(db.String(256), nullable=False)
    item_price = db.Column(db.Integer,nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.now())

  
class UserActivity(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    message_id = db.Column(db.String, unique=True, nullable=False)
    email = db.Column(db.String(256), unique=True)
    click_buy = db.Column(db.Integer)
    fraud_account_buy = db.Column(db.Integer)
    subscription_controller = db.Column(db.Boolean, default=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.now())

class ChatHistory(db.Model):
    __tablename__ = 'chat_history'

    id = db.Column(db.Integer, primary_key=True)
    mobile = db.Column(db.String)
    history = db.Column(db.Text)