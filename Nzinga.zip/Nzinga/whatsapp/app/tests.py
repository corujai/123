import fitz

# Abrir o PDF original
pdf_path = "real.pdf"
doc = fitz.open(pdf_path)
doc2 = fitz.open()
doc2._newPage()
# Definir a palavra a ser substituída e a palavra de substituição
palavra_original = "Comprovativo"
palavra_substituta = "COMPROVATIVO"

for page_num in range(doc.page_count):
  # Carregar a página
  page = doc.load_page(page_num)
  page2 = doc.load_page(0)

  # Obter as palavras na página
  words = page.search_for(palavra_original)

  # Localizar as ocorrências da palavra original
  for word_idx, word in enumerate(words):
    # Encontrar as coordenadas da palavra
    x1, y1, x2, y2 = words[0][0],words[0][1],words[0][2],words[0][3]

    # Gerar um novo texto com a palavra substituída
    new_text = page.get_text("words")[word_idx][4].replace(palavra_original, palavra_substituta)


    # Atualizar o texto da página
    page2.add_rect_annot(rect=[x1,y1,x2,y2])

# Salvar o novo PDF
new_pdf_path = "documento_traduzido.pdf"
doc2.save(new_pdf_path)
