import vertexai
from models import db, ChatHistory
from vertexai.preview.generative_models import GenerativeModel, ChatSession, Content, Part, Image
from google.oauth2 import service_account
from vertexai.preview import generative_models
import json
from flask import Flask
from config import Config
from timeit import timeit

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///../../instance/app-bk.sqlite3'
db.init_app(app)


credentials = service_account.Credentials.from_service_account_file("plenary-edition-anotherone.json")

vertexai.init(project="plenary-edition-396623", location="northamerica-northeast1", credentials=credentials)

def get_chat_response(chat: ChatSession, prompt):
	responses = chat.send_message(prompt, stream=False)
	print(responses)

	return responses.text


def chat_message(mobile, message, img, image=False):

	with app.app_context():

		model = GenerativeModel("gemini-1.0-pro-vision")
		chat_history = ChatHistory.query.filter(ChatHistory.mobile == mobile).first()



		if not chat_history:
			empty_chat = [Content(role="user", parts=[Part.from_text("Hi")]), Content(role="model", parts=[Part.from_text("Hello.")])]
			empty_chat = json.dumps([{'role': content.role, 'parts': [{'text': part.text} for part in content.parts]} for content in
						empty_chat])
			chat_history = ChatHistory(mobile=mobile, history=json.dumps([*json.loads(json.dumps([])), json.loads(empty_chat)]))
			db.session.add(chat_history)

		db.session.commit()

		deserialized_content = [
			Content(
				role=item[i]['role'],
				parts=[
					Part.from_text(part['text']) for part in item[i]['parts']
				]
			)
			for item in json.loads(chat_history.history)
			for i in range(2)
		]


		chat = model.start_chat(history=deserialized_content)

		response = chat.send_message(message)
		if image:
			response = model.generate_content([img, message])
			print("1: ",response.text)

		message_parts = [Content(role="user", parts=[Part.from_text(message)]), Content(role="model", parts=[Part.from_text(response.text)])]

		serialized_content = json.dumps([{'role': content.role, 'parts': [{'text': part.text} for part in content.parts]} for content in message_parts])
		chat_history.history = json.dumps([*json.loads(chat_history.history), json.loads(serialized_content)])

		db.session.commit()


	return print(response)

with open("C:\\Users\\hp\Pictures\\nzinga\\bancadas\\GLt8bRlaH4TyU4sCAPosCp0U8XQZbmdjAAAF.mp4", "rb") as file:
	vid = file.read()

img= generative_models.Part.from_data(vid, mime_type="video/mp4")
chat_message(244922623930, message="Descreve em duas palavras", img=img, image=True)
