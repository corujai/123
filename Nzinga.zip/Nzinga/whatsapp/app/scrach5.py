import vertexai
from vertexai.generative_models import (
    Content,
    FunctionDeclaration,
    GenerativeModel,
    ChatSession,
    Part,
    Tool,
)
from google.oauth2 import service_account
import google.generativeai as genai
import requests

credentials = service_account.Credentials.from_service_account_file("plenary-edition-anotherone.json")

vertexai.init(project="plenary-edition-396623", location="northamerica-northeast1", credentials=credentials)
L = {'244925623934': [Content(role="user", parts=[Part.from_text("Onde fica Angola")]), Content(role="model", parts=[Part.from_text("Na Africa")])]}
model = GenerativeModel("gemini-1.0-pro")

get_exchange_rate_func = FunctionDeclaration(
    name="get_exchange_rate",
    description="Get the exchange rate for currencies between countries",
    parameters={
    "type": "object",
    "properties": {
        "currency_date": {
            "type": "string",
            "description": "A date that must always be in YYYY-MM-DD format or the value 'latest' if a time period is not specified"
        },
        "currency_from": {
            "type": "string",
            "description": "The currency to convert from in ISO 4217 format"
        },
        "currency_to": {
            "type": "string",
            "description": "The currency to convert to in ISO 4217 format"
        }
    },
         "required": [
            "currency_from",
            "currency_date",
      ]
  },
)

exchange_rate_tool = Tool(
    function_declarations=[get_exchange_rate_func],
)

prompt = """What is the exchange rate from Australian dollars to Swedish krona?
How much is 500 Australian dollars worth in Swedish krona?"""

response = model.generate_content(
    prompt,
    tools=[exchange_rate_tool],
)

print("1: ",response.candidates[0].content)

params = {}
for key, value in response.candidates[0].content.parts[0].function_call.args.items():
    params[key[9:]] = value

print("2: ",params)

proxies = {'https': '192.168.42.129:8080'}
headers = {'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36'}
headers = headers
proxies = proxies

url = f"https://api.frankfurter.app/{params['date']}"
api_response = requests.get(url, params=params, headers=headers, proxies=proxies)

print("3: ",api_response.text)

response = model.generate_content(
    [
    Content(role="user", parts=[
        Part.from_text(prompt + """Give your answer in steps with lots of detail
            and context, including the exchange rate and date."""),
    ]),
    Content(role="function", parts=[
        Part.from_dict({
            "function_call": {
                "name": "get_exchange_rate",
            }
        })
    ]),
    Content(role="function", parts=[
        Part.from_function_response(
            name="get_exchange_rate",
            response={
                "content": api_response.text,
            }
        )
    ]),
    ],
    tools=[exchange_rate_tool],
)


print("4: ",response.candidates[0].content.parts[0].text)

"""

chat = model.start_chat(history=L["244925623934"])

def get_chat_response(chat: ChatSession, prompt: str) -> str:
    responses = chat.send_message(prompt, stream=False)
    return responses


prompt = "Olá"
print(get_chat_response(chat, prompt))
print(chat.history)
"""





