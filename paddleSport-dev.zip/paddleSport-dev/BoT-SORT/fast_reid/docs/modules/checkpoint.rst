fastreid.checkpoint
=============================

.. automodule:: fastreid.utils.checkpoint
    :members:
    :undoc-members:
    :show-inheritance:
