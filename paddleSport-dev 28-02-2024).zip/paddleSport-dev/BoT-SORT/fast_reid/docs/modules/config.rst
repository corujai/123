fastreid.config 
=========================

Related tutorials: :doc:`../tutorials/configs`, :doc:`../tutorials/extend`.

.. automodule:: fastreid.config
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:


Config References
-----------------

.. literalinclude:: ../../fastreid/config/defaults.py
  :language: python
  :linenos:
  :lines: 4-
